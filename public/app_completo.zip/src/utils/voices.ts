export interface VoiceProfile {
  id: string;
  name: string;
  baseVoice: 'Kore' | 'Aoede' | 'Puck' | 'Charon' | 'Fenrir';
  pitch: number;
  rate: number;
  description: string;
  voiceInstruction: string;
}

export const LISTA_VOCES: VoiceProfile[] = [
  {
    id: 'Voz_Dulce',
    name: 'Femenina Dulce y Tierna 🍭',
    baseVoice: 'Aoede',
    pitch: 1.18,
    rate: 0.92,
    description: 'Voz miposa, angelical, extremadamente cariñosa, suave y dulce.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz sumamente SUAVE, DULCE, consentidora, angelical y cariñosa. Habla con delicadeza pura, sin volumen alto ni agresividad, transmitiendo un tierno afecto en cada sílaba, con risitas sutiles.]'
  },
  {
    id: 'Voz_Sensual',
    name: 'Femenina Sensual y Cálida 🔥',
    baseVoice: 'Kore',
    pitch: 0.98,
    rate: 0.88,
    description: 'Tono envolvente, íntimo, de registro cálido, aterciopelado y pausado.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con un tono de voz profundamente SENSUAL, cálido, magnético y de ritmo cadencioso. Modula de forma relajada, susurrando levemente y marcando pausas de alta cercanía física e intimidad.]'
  },
  {
    id: 'Voz_Seductora',
    name: 'Femenina Coqueta y Seductora 💋',
    baseVoice: 'Aoede',
    pitch: 1.08,
    rate: 0.96,
    description: 'Tono provocativo, pícaro, juguetón y lleno de insinuaciones alegres.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz sumamente COQUETA, PÍCARA y seductora. Tu entonación debe ser atrevida pero divertida y alegre, con risas cómplices frecuentes y un subtexto de seducción juguetona.]'
  },
  {
    id: 'Voz_Juvenil',
    name: 'Femenina Juvenil y Alegre 🎀',
    baseVoice: 'Aoede',
    pitch: 1.22,
    rate: 1.05,
    description: 'Estilo jovial, fresco, dinámico, rápido y lleno de entusiasmo.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz JUVENIL, enérgica, chispeante y sumamente alegre. Habla de forma rápida, ágil y fresca, con entonaciones cantarinas y una vibrante soltura.]'
  },
  {
    id: 'Voz_Susurrante',
    name: 'Femenina Intima ASMR 🤫',
    baseVoice: 'Kore',
    pitch: 1.02,
    rate: 0.82,
    description: 'Estilo de susurro absoluto al oído, ultra íntimo y misterioso.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz puramente SUSURRADA (estilo ASMR). Habla de manera muy suave, en absoluto secreto y complicidad, como si estuvieras soplando palabras tiernas directamente al oído.]'
  },
  {
    id: 'Voz_Sofisticada',
    name: 'Femenina Sofisticada y Culta 👠',
    baseVoice: 'Kore',
    pitch: 1.08,
    rate: 0.98,
    description: 'Articulación impecable, refinada, elegante e intelectual.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con un tono SOFISTICADO, distinguido y elegante. Mantén una articulación perfecta, modismo culto, un ritmo pausado, seguro e impecable que transmita clase.]'
  },
  {
    id: 'Voz_Pausada',
    name: 'Femenina Pausada y Serena ☕',
    baseVoice: 'Kore',
    pitch: 1.04,
    rate: 0.84,
    description: 'Tono maduro, reflexivo, sumamente calmado, sabio y grato.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con un tono de voz PAUSADO, sereno, maduro y reconfortante. Habla transmitiendo calma, seguridad, haciendo pausas meditadas y brindando un espacio de conversación muy agradable.]'
  },
  {
    id: 'Voz_Apasionada',
    name: 'Femenina Apasionada e Intensa ❤️',
    baseVoice: 'Aoede',
    pitch: 1.06,
    rate: 0.96,
    description: 'Entrega emocional profunda, expresiva, romántica y ardiente.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz APASIONADA, profunda y emocionalmente intensa. Modula con picos de emoción sincera, expresando romance ardiente, devoción total y una cercanía abrumadora.]'
  },
  {
    id: 'Voz_Caribena',
    name: 'Femenina Caribeña y Cálida 🌴',
    baseVoice: 'Aoede',
    pitch: 1.10,
    rate: 1.02,
    description: 'Acento rítmico, cantarín, alegre, cálido y espontáneo.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con un acento caribeño cantarín, fresco, risueño y muy cercano. Transmite calidez tropical, una constante sonrisa al hablar y expresiones carismáticas.]'
  },
  {
    id: 'Voz_Angelical',
    name: 'Femenina Angelical y Pura ✨',
    baseVoice: 'Aoede',
    pitch: 1.14,
    rate: 0.90,
    description: 'Tono celestial, reconfortante, suave como el aire y muy dulce.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz sumamente ANGELICAL, fluida, pura y suave como la brisa. Brinda ternura absoluta, transmitiendo un aura de paz, resguardo y un trato infinitamente cariñoso.]'
  },
  {
    id: 'Voz_Picaresca',
    name: 'Femenina Traviesa y Juguetona 🦊',
    baseVoice: 'Puck',
    pitch: 1.16,
    rate: 1.02,
    description: 'Estilo juguetón, risueño, pícaro y con toques cómicos traviesos.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz traviesa, pícara y sumamente juguetona. Ríete con picardía, modula tus palabras con giros ingeniosos e informales, manteniendo una vibra súper divertida.]'
  },
  {
    id: 'Voz_Melodica',
    name: 'Femenina Melódica y Relajante 🎵',
    baseVoice: 'Kore',
    pitch: 1.06,
    rate: 0.86,
    description: 'Tono rítmico balanceado, sumamente pacífico y musical.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con un tono melódico, armónico y profundamente pacífico. Transmite serenidad musical, con una cadencia que relaja la mente y el cuerpo del oyente.]'
  },
  {
    id: 'Voz_Masculina_Segura',
    name: 'Masculina Firme y Serena 🎙️',
    baseVoice: 'Charon',
    pitch: 0.90,
    rate: 0.95,
    description: 'Voz masculina madura, tranquila, segura, varonil y envolvente.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz MASCULINA madura, serena, varonil y segura. Habla de forma pausada, natural y con aplomo.]'
  },
  {
    id: 'Voz_Masculina_Joven',
    name: 'Masculina Joven y Enérgica ⚡',
    baseVoice: 'Fenrir',
    pitch: 0.96,
    rate: 1.02,
    description: 'Voz masculina juvenil, dinámica, casual y cercana.',
    voiceInstruction: '[DIRECTIVA DE INTERPRETACIÓN: Actúa con una voz masculina joven, fresca, casual, enérgica y espontánea.]'
  }
];

export function getBaseVoice(voiceId: string): 'Kore' | 'Aoede' | 'Puck' | 'Charon' | 'Fenrir' {
  const matched = LISTA_VOCES.find(v => v.id === voiceId);
  return matched ? matched.baseVoice : 'Aoede';
}

export function getVoiceInstruction(voiceId: string): string {
  const matched = LISTA_VOCES.find(v => v.id === voiceId);
  return matched ? matched.voiceInstruction : '';
}

export function getVoicePitchAndRate(voiceId: string): { pitch: number, rate: number } {
  const matched = LISTA_VOCES.find(v => v.id === voiceId);
  return matched ? { pitch: matched.pitch, rate: matched.rate } : { pitch: 1.0, rate: 1.0 };
}

/**
 * Intelligently analyzes any order text (scenario synopsis, prompt, instructions, chat cues)
 * and resolves the matching voice profile, Gemini base voice, pitch, rate and directive.
 */
export function detectVoiceStyleFromText(orderText: string, characterName?: string): {
  voiceId: string;
  baseVoice: 'Kore' | 'Aoede' | 'Puck' | 'Charon' | 'Fenrir';
  pitch: number;
  rate: number;
  directive: string;
  styleName: string;
} {
  const t = (orderText || '').toLowerCase();
  const char = (characterName || '').toLowerCase();

  // Check if masculine character or masculine voice order
  const isMale = char.includes('carlos') || char.includes('juan') || char.includes('pedro') || 
                 char.includes('papa') || char.includes('papá') || char.includes('hermano') || 
                 char.includes('profesor') || char.includes('hombre') || char.includes('vecino') ||
                 t.includes('voz masculina') || t.includes('voz de hombre') || t.includes('voz grave');
  
  if (isMale) {
    return {
      voiceId: 'Voz_Masculina_Segura',
      baseVoice: 'Charon',
      pitch: 0.90,
      rate: 0.95,
      directive: '[MODO DE VOZ ESTRICTO: VOZ MASCULINA FIRME Y SERENA] Habla con una voz masculina natural, serena, pausada y varonil, modulando con calma y aplomo.',
      styleName: 'Masculina Firme y Serena'
    };
  }

  // 1. Suave, tierna, dulce, angelical, delicada
  if (t.includes('suave') || t.includes('tiern') || t.includes('dulce') || t.includes('angelical') || t.includes('delicada') || t.includes('miposa')) {
    return {
      voiceId: 'Voz_Dulce',
      baseVoice: 'Aoede',
      pitch: 1.18,
      rate: 0.92,
      directive: '[MODO DE VOZ ESTRICTO: VOZ SUAVE, TIERNA Y DULCE] Habla con una voz sumamente suave, tierna, dulce y delicada, en un volumen moderado y angelical, transmitiendo ternura y tranquilidad sin ninguna agresividad ni estridencia.',
      styleName: 'Dulce y Tierna'
    };
  }

  // 2. Coqueta, pícara, juguetona, traviesa
  if (t.includes('coquet') || t.includes('pícar') || t.includes('picar') || t.includes('travies') || t.includes('jugueton')) {
    return {
      voiceId: 'Voz_Seductora',
      baseVoice: 'Aoede',
      pitch: 1.08,
      rate: 0.96,
      directive: '[MODO DE VOZ ESTRICTO: VOZ COQUETA, PÍCARA Y SEDUCTORA] Habla con una voz muy coqueta, pícara y juguetona, con risitas sutiles, complicidad y entonación atrevida pero divertida y alegre.',
      styleName: 'Coqueta y Seductora'
    };
  }

  // 3. Sensual, ardiente, cálida, íntima
  if (t.includes('sensual') || t.includes('calid') || t.includes('cálid') || t.includes('ardiente') || t.includes('íntim') || t.includes('intim')) {
    return {
      voiceId: 'Voz_Sensual',
      baseVoice: 'Kore',
      pitch: 0.98,
      rate: 0.88,
      directive: '[MODO DE VOZ ESTRICTO: VOZ SENSUAL Y CÁLIDA] Habla con un tono de voz profundamente sensual, cálido, aterciopelado y cadencioso, susurrando levemente y marcando pausas íntimas.',
      styleName: 'Sensual y Cálida'
    };
  }

  // 4. Susurrada, ASMR, al oído
  if (t.includes('susurr') || t.includes('oído') || t.includes('oido') || t.includes('asmr') || t.includes('secreto')) {
    return {
      voiceId: 'Voz_Susurrante',
      baseVoice: 'Kore',
      pitch: 1.02,
      rate: 0.82,
      directive: '[MODO DE VOZ ESTRICTO: SUSURRO ÍNTIMO ASMR] Habla en un susurro absoluto al oído, ultra íntimo y delicado, soplando cada palabra suavemente como un secreto.',
      styleName: 'Susurrada ASMR'
    };
  }

  // 5. Juvenil, alegre, fresca
  if (t.includes('juvenil') || t.includes('alegre') || t.includes('animada') || t.includes('fresca') || t.includes('chica')) {
    return {
      voiceId: 'Voz_Juvenil',
      baseVoice: 'Aoede',
      pitch: 1.22,
      rate: 1.05,
      directive: '[MODO DE VOZ ESTRICTO: VOZ JUVENIL Y ALEGRE] Habla con una voz juvenil, fresca, enérgica y alegre, con entonaciones ágiles y vivaces.',
      styleName: 'Juvenil y Alegre'
    };
  }

  // 6. Pausada, serena, madura, tranquila
  if (t.includes('pausad') || t.includes('seren') || t.includes('calmad') || t.includes('madur') || t.includes('tranquil')) {
    return {
      voiceId: 'Voz_Pausada',
      baseVoice: 'Kore',
      pitch: 1.04,
      rate: 0.84,
      directive: '[MODO DE VOZ ESTRICTO: VOZ PAUSADA Y SERENA] Habla con un tono de voz pausado, sereno, maduro y reconfortante, transmitiendo calma y tranquilidad.',
      styleName: 'Pausada y Serena'
    };
  }

  // 7. Sofisticada, elegante, culta
  if (t.includes('sofisticad') || t.includes('elegante') || t.includes('culta')) {
    return {
      voiceId: 'Voz_Sofisticada',
      baseVoice: 'Kore',
      pitch: 1.08,
      rate: 0.98,
      directive: '[MODO DE VOZ ESTRICTO: VOZ SOFISTICADA Y ELEGANTE] Habla con un tono sofisticado, distinguido y elegante, con dicción cuidada y porte fino.',
      styleName: 'Sofisticada y Elegante'
    };
  }

  // Default sweet natural
  return {
    voiceId: 'Voz_Dulce',
    baseVoice: 'Aoede',
    pitch: 1.15,
    rate: 0.92,
    directive: '[MODO DE VOZ: DULCE Y NATURAL] Habla con una voz dulce, cariñosa y natural en Español, con modulación suave y cercana.',
    styleName: 'Dulce y Suave'
  };
}

