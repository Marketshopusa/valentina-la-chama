import React, { useState } from 'react';
import { X, BookOpen, Plus, Play, Sparkles, User, Flame } from 'lucide-react';
import { StoryScenario, Persona } from '../types';
import { CreateStoryModal } from './CreateStoryModal';

interface StorySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  scenarios: StoryScenario[];
  activeScenarioId: string;
  onSelectScenario: (scenario: StoryScenario) => void;
  onCreateScenario: (newScenario: StoryScenario) => void;
  personas: Persona[];
}

export const StorySelectorModal: React.FC<StorySelectorModalProps> = ({
  isOpen,
  onClose,
  scenarios,
  activeScenarioId,
  onSelectScenario,
  onCreateScenario,
  personas
}) => {
  const [isCreating, setIsCreating] = useState(false);

  if (!isOpen) return null;

  if (isCreating) {
    return (
      <CreateStoryModal
        isOpen={true}
        onClose={() => setIsCreating(false)}
        onCreateStory={(newScen) => {
          onCreateScenario(newScen);
          setIsCreating(false);
          onClose();
        }}
        personas={personas}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#141021] border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/5 pb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-fuchsia-600 to-pink-500 flex items-center justify-center shadow-lg">
              <Flame className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">Catálogo de Historias & Roleplay</h2>
              <p className="text-xs text-zinc-400">Selecciona o crea un escenario interactivo</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto py-5 space-y-4 pr-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Historias Disponibles ({scenarios.length})
            </span>
            <button
              onClick={() => setIsCreating(true)}
              className="px-3.5 py-1.5 rounded-xl bg-pink-600/90 hover:bg-pink-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Crear Historia</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {scenarios.map((scen) => {
              const isActive = scen.id === activeScenarioId;

              return (
                <div 
                  key={scen.id}
                  onClick={() => {
                    onSelectScenario(scen);
                    onClose();
                  }}
                  className={`
                    group relative rounded-2xl overflow-hidden border p-4 cursor-pointer transition-all duration-300
                    ${isActive 
                      ? 'border-pink-500 bg-pink-950/20 shadow-lg shadow-pink-900/20' 
                      : 'border-white/10 bg-zinc-900/60 hover:border-purple-500/50 hover:bg-zinc-900/90'}
                  `}
                >
                  {scen.coverImage && (
                    <div className="h-32 -mx-4 -mt-4 mb-3 overflow-hidden relative">
                      <img 
                        src={scen.coverImage} 
                        alt={scen.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#141021] via-[#141021]/40 to-transparent" />
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-bold text-white capitalize text-sm group-hover:text-pink-400 transition-colors">
                      {scen.title}
                    </h3>
                    {isActive && (
                      <span className="px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-400 text-[10px] font-bold uppercase">
                        Activa
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed">
                    {scen.synopsis}
                  </p>

                  <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-[11px] text-zinc-400">
                    <span>tú: <b className="text-white">{scen.userName || 'willian'}</b></span>
                    <span>rol: <b className="text-pink-300">{scen.characterRole}</b></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
export default StorySelectorModal;
