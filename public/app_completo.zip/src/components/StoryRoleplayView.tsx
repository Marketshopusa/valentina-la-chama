import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, RotateCcw, Volume2, VolumeX, Phone, PhoneOff, Mic, MicOff, 
  Send, Sparkles, Image as ImageIcon, Loader2, Maximize2, Settings, 
  User, Check, X, RefreshCw, Plus, Edit3
} from 'lucide-react';
import { Persona, ConnectionStatus, Message, StoryScenario } from '../types';
import { EditStoryModal } from './EditStoryModal';

interface StoryRoleplayViewProps {
  scenario: StoryScenario;
  persona: Persona;
  currentMedia: string;
  messages: Message[];
  status: ConnectionStatus;
  isSpeaking: boolean;
  isMuted: boolean;
  micLevel: number;
  isTyping: boolean;
  autoSpeak: boolean;
  onSendMessage: (text: string) => void;
  onToggleMute: () => void;
  onToggleCall: () => void;
  onToggleAutoSpeak: () => void;
  onRestartStory: () => void;
  onBackToHistorias: () => void;
  onOpenCreateStory?: () => void;
  onOpenSettings: () => void;
  onSetCardMedia: (mediaUrl: string) => void;
  onUpdateScenario: (updated: StoryScenario, restartChat?: boolean) => void;
  onAttachSceneImage?: (messageId: string, imageUrl: string) => void;
}

export const StoryRoleplayView: React.FC<StoryRoleplayViewProps> = ({
  scenario,
  persona,
  currentMedia,
  messages,
  status,
  isSpeaking,
  isMuted,
  micLevel,
  isTyping,
  autoSpeak,
  onSendMessage,
  onToggleMute,
  onToggleCall,
  onToggleAutoSpeak,
  onRestartStory,
  onBackToHistorias,
  onOpenCreateStory,
  onOpenSettings,
  onSetCardMedia,
  onUpdateScenario,
  onAttachSceneImage
}) => {
  const [inputText, setInputText] = useState('');
  const [activeTab, setActiveTab] = useState<'both' | 'scene' | 'chat'>('both');
  const [generatingMessageId, setGeneratingMessageId] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [sceneImages, setSceneImages] = useState<Record<string, string>>({});
  const [isEditingMetadata, setIsEditingMetadata] = useState(false);
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  const chatScrollRef = useRef<HTMLDivElement>(null);
  const speechRecognitionRef = useRef<any>(null);

  const isInCall = status === ConnectionStatus.CONNECTED;
  const isConnecting = status === ConnectionStatus.CONNECTING || status === ConnectionStatus.RECONNECTING || status === ConnectionStatus.RESETTING;

  // Track call timer if connected
  useEffect(() => {
    let interval: any;
    if (isInCall) {
      interval = setInterval(() => setCallDuration(d => d + 1), 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(interval);
  }, [isInCall]);

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const formatTimestamp = (timestamp: number) => {
    const d = new Date(timestamp);
    const h = d.getHours().toString().padStart(2, '0');
    const m = d.getMinutes().toString().padStart(2, '0');
    return `${h}:${m}`;
  };

  // Scroll to bottom on new message
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  // Web Speech recognition for quick voice input in chat
  const handleToggleVoiceInput = () => {
    if (isListeningMic) {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.stop();
      }
      setIsListeningMic(false);
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert("El reconocimiento de voz en navegador no está soportado en este dispositivo. Puedes usar la llamada en vivo.");
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.lang = 'es-ES';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListeningMic(true);
      };

      recognition.onresult = (e: any) => {
        const transcript = e.results[0][0].transcript;
        if (transcript) {
          setInputText(prev => prev ? `${prev} ${transcript}` : transcript);
        }
        setIsListeningMic(false);
      };

      recognition.onerror = () => {
        setIsListeningMic(false);
      };

      recognition.onend = () => {
        setIsListeningMic(false);
      };

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.warn("Speech recognition error:", e);
      setIsListeningMic(false);
    }
  };

  // Generate illustration for a specific scene message strictly within the chat bubble
  const handleIllustrateScene = async (msg: Message) => {
    if (generatingMessageId) return;
    setGeneratingMessageId(msg.id);

    try {
      // Find the previous message to give full situational context (what the user just said or did)
      const msgIndex = messages.findIndex(m => m.id === msg.id);
      const previousMsg = msgIndex > 0 ? messages[msgIndex - 1] : undefined;

      const response = await fetch('/api/generate-scene-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sceneText: msg.text,
          previousText: previousMsg?.text || '',
          characterName: scenario.characterName || persona.name,
          scenarioTitle: scenario.title,
          userRole: scenario.userRole || scenario.userName || 'hombre',
          characterRole: scenario.characterRole || 'mujer',
          referenceImage: currentMedia || scenario.coverImage || persona.defaultImage || '',
          characterDescription: scenario.development || persona.instruction || ''
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.imageUrl) {
          msg.sceneImage = data.imageUrl;
          setSceneImages(prev => ({ ...prev, [msg.id]: data.imageUrl }));
          onAttachSceneImage?.(msg.id, data.imageUrl);
          return;
        }
      }
      
      // Resilient client-side fallback if server didn't provide image URL
      const seed = Math.floor(Math.random() * 899999) + 100000;
      const charName = scenario.characterName || persona.name || "Valentina";
      const promptFallback = encodeURIComponent(`Cinematic 35mm photograph of ${charName} and her lover in an intimate romantic scene, atmospheric lighting, 8k, photorealistic`);
      const fallbackUrl = `https://image.pollinations.ai/prompt/${promptFallback}?width=1024&height=576&nologo=true&model=flux&seed=${seed}`;
      msg.sceneImage = fallbackUrl;
      setSceneImages(prev => ({ ...prev, [msg.id]: fallbackUrl }));
      onAttachSceneImage?.(msg.id, fallbackUrl);
    } catch (err) {
      console.error("Failed to generate scene illustration:", err);
      // Even on network error, ensure user gets an illustration
      const seed = Math.floor(Math.random() * 899999) + 100000;
      const charName = scenario.characterName || persona.name || "Valentina";
      const promptFallback = encodeURIComponent(`Cinematic 35mm photograph of ${charName} passionate romantic scene, photorealistic, 8k`);
      const fallbackUrl = `https://image.pollinations.ai/prompt/${promptFallback}?width=1024&height=576&nologo=true&model=flux&seed=${seed}`;
      msg.sceneImage = fallbackUrl;
      setSceneImages(prev => ({ ...prev, [msg.id]: fallbackUrl }));
      onAttachSceneImage?.(msg.id, fallbackUrl);
    } finally {
      setGeneratingMessageId(null);
    }
  };

  const isVideo = typeof currentMedia === 'string' && (
    currentMedia.startsWith('data:video') || 
    currentMedia.includes('video/') || 
    currentMedia.includes('.mp4') || 
    currentMedia.includes('.webm')
  );

  return (
    <div className="w-full h-full min-h-screen bg-[#0d0a14] text-white flex flex-col overflow-hidden font-sans select-none">
      {/* TOP HEADER */}
      <header className="h-14 border-b border-white/5 bg-[#120e1c]/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between z-30 shrink-0">
        <div className="flex items-center gap-2 sm:gap-3">
          <button 
            onClick={onBackToHistorias}
            className="flex items-center gap-1.5 text-zinc-400 hover:text-white transition-colors text-xs sm:text-sm font-medium cursor-pointer group"
          >
            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
            <span>Historias</span>
          </button>

          {onOpenCreateStory && (
            <button 
              onClick={onOpenCreateStory}
              className="flex items-center gap-1.5 bg-[#d926a9]/90 hover:bg-[#c026d3] text-white px-3 py-1.5 rounded-xl text-xs font-semibold shadow-md shadow-pink-950/40 transition-all cursor-pointer active:scale-95"
              title="Crear Nueva Historia"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Nueva Historia</span>
              <span className="sm:hidden">Crear</span>
            </button>
          )}

          <span className="hidden md:inline text-zinc-700">|</span>

          <button 
            onClick={() => setIsEditingMetadata(true)}
            className="flex items-center gap-2 text-zinc-300 hover:text-white text-xs bg-white/5 hover:bg-white/10 px-3 py-1 rounded-full border border-white/5 transition-all cursor-pointer"
            title="Editar parámetros y portada de la historia"
          >
            <Edit3 className="w-3 h-3 text-pink-400" />
            <span className="capitalize font-semibold text-pink-400 max-w-[130px] sm:max-w-[200px] truncate">{scenario.title}</span>
            <span className="text-zinc-500 text-[10px] hidden sm:inline">({scenario.characterRole})</span>
          </button>
        </div>

        {/* Center / Mobile tab switcher */}
        <div className="flex md:hidden bg-zinc-900 border border-white/10 rounded-full p-0.5 text-xs">
          <button 
            onClick={() => setActiveTab('scene')}
            className={`px-3 py-1 rounded-full font-medium transition-all ${activeTab === 'scene' ? 'bg-[#c026d3] text-white shadow' : 'text-zinc-400'}`}
          >
            🎬 Tarjeta
          </button>
          <button 
            onClick={() => setActiveTab('chat')}
            className={`px-3 py-1 rounded-full font-medium transition-all ${activeTab === 'chat' ? 'bg-[#c026d3] text-white shadow' : 'text-zinc-400'}`}
          >
            💬 Chat
          </button>
        </div>

        {/* Right header controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Audio Auto-read toggle */}
          <button
            onClick={onToggleAutoSpeak}
            className={`p-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              autoSpeak ? 'bg-purple-900/40 text-pink-400 border border-purple-500/30' : 'bg-white/5 text-zinc-400 hover:text-white'
            }`}
            title={autoSpeak ? "Voz automática activada" : "Voz automática desactivada"}
          >
            {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden lg:inline text-[11px]">{autoSpeak ? 'Voz On' : 'Voz Off'}</span>
          </button>

          {/* Quick Voice Call Button */}
          <button
            onClick={onToggleCall}
            disabled={isConnecting}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-2 transition-all cursor-pointer ${
              isInCall 
                ? 'bg-red-600/90 hover:bg-red-500 text-white shadow-lg shadow-red-900/30' 
                : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-md'
            }`}
            title={isInCall ? "Finalizar llamada" : "Conectar llamada de voz"}
          >
            {isInCall ? (
              <>
                <PhoneOff className="w-3.5 h-3.5" />
                <span className="font-mono">{formatTimer(callDuration)}</span>
              </>
            ) : isConnecting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span className="hidden sm:inline">Conectando...</span>
              </>
            ) : (
              <>
                <Phone className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Llamada en Vivo</span>
              </>
            )}
          </button>

          {/* Settings button */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            title="Ajustes de Personaje y Voz"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MAIN DUAL-PANE CONTENT */}
      <main className="flex-1 w-full max-w-[1550px] mx-auto p-3 sm:p-5 flex gap-5 overflow-hidden justify-center items-stretch">
        {/* LEFT COLUMN: ANIMATED VERTICAL CARD */}
        <div className={`
          ${activeTab === 'chat' ? 'hidden' : 'flex'} 
          md:flex flex-col shrink-0 w-full sm:w-[440px] md:w-[480px] lg:w-[540px] xl:w-[580px] 
          h-[calc(100vh-5rem)] max-h-[840px] 
          relative rounded-[28px] overflow-hidden 
          border border-white/10 shadow-2xl bg-zinc-950 select-none
        `}>
          {/* Card Media (Video or Image) */}
          <div className="absolute inset-0 z-0 bg-black">
            {isVideo ? (
              <video 
                key={currentMedia}
                src={currentMedia}
                autoPlay loop muted playsInline
                className={`w-full h-full object-cover transition-transform duration-1000 ${isSpeaking ? 'scale-105' : 'scale-100'}`}
              />
            ) : (
              <img 
                key={currentMedia}
                src={currentMedia}
                alt={scenario.title}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover transition-transform duration-1000 ${isSpeaking ? 'scale-105' : 'scale-100'}`}
              />
            )}

            {/* Subtle dark gradient overlay: fades out in call so user can delight in the full image */}
            <div className={`absolute inset-0 bg-gradient-to-t from-black/95 via-black/35 to-transparent pointer-events-none transition-opacity duration-500 ${isInCall ? 'opacity-0' : 'opacity-100'}`} />
            <div className={`absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/60 to-transparent pointer-events-none transition-opacity duration-500 ${isInCall ? 'opacity-40' : 'opacity-100'}`} />
          </div>

          {/* Minimal Floating Call / Mic Controls (Replaces wide bar) */}
          <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
            {/* When in call, small mute/unmute mic toggle */}
            {isInCall && (
              <button 
                onClick={onToggleMute}
                className={`w-9 h-9 rounded-full border backdrop-blur-md flex items-center justify-center transition-all cursor-pointer shadow-lg active:scale-95 ${
                  isMuted 
                    ? 'bg-red-600/80 border-red-500 text-white animate-pulse' 
                    : 'bg-black/50 hover:bg-black/70 border-white/20 text-white/90'
                }`}
                title={isMuted ? "Activar micrófono" : "Silenciar micrófono"}
              >
                {isMuted ? <MicOff className="w-4 h-4 text-red-200" /> : <Mic className="w-4 h-4" />}
              </button>
            )}

            {/* Phone button: GREEN when in call (hover to hang up), RED when hung up (click to call) */}
            <button
              onClick={onToggleCall}
              className={`w-9 h-9 rounded-full flex items-center justify-center shadow-xl transition-all cursor-pointer group active:scale-95 border ${
                isInCall
                  ? 'bg-emerald-500 hover:bg-red-600 border-emerald-400/50 text-white shadow-emerald-950/60'
                  : 'bg-red-600/90 hover:bg-emerald-600 border-red-500/50 text-white shadow-red-950/60'
              }`}
              title={isInCall ? "En llamada (Click para colgar)" : "Iniciar llamada"}
            >
              {isInCall ? (
                <>
                  <Phone className="w-4 h-4 group-hover:hidden animate-pulse" />
                  <PhoneOff className="w-4 h-4 hidden group-hover:block" />
                </>
              ) : (
                <Phone className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Sound waves visualization when character speaks */}
          {isSpeaking && (
            <div className="absolute top-5 left-5 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 pointer-events-none">
              <span className="w-2 h-2 rounded-full bg-pink-500 animate-pulse" />
              <div className="flex items-center gap-0.5">
                <div className="w-1 h-3 bg-pink-500 rounded-full animate-bounce [animation-delay:-0.4s]" />
                <div className="w-1 h-4 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.2s]" />
                <div className="w-1 h-3 bg-pink-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
              </div>
            </div>
          )}

          {/* Card Bottom Content: ONLY VISIBLE WHILE NOT IN CALL (disappears during call for full unobstructed view) */}
          {!isInCall && (
            <div className="absolute bottom-0 inset-x-0 z-10 p-5 sm:p-6 flex flex-col justify-end pointer-events-auto transition-all duration-300">
              {/* Story Title & Edit Action */}
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white capitalize drop-shadow-md truncate">
                  {scenario.title}
                </h2>
                <button
                  onClick={() => setIsEditingMetadata(true)}
                  className="p-1.5 rounded-xl bg-black/40 hover:bg-black/60 border border-white/10 text-zinc-300 hover:text-white transition-all cursor-pointer shrink-0"
                  title="Editar parámetros y portada de la historia"
                >
                  <Edit3 className="w-3.5 h-3.5 text-pink-400" />
                </button>
              </div>

              {/* Synopsis / Description */}
              <p className="text-xs sm:text-sm text-zinc-300/90 mt-1.5 line-clamp-3 leading-relaxed drop-shadow">
                {scenario.synopsis}
              </p>

              {/* Metadata Tags */}
              <div className="mt-4 pt-3 border-t border-white/10 flex flex-col gap-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-zinc-400">tú:</span>
                    <span className="font-semibold text-white uppercase tracking-wider">
                      {scenario.userRole || scenario.userName || 'willian'}
                    </span>
                  </div>
                  {scenario.isExplicit18 && (
                    <span className="px-2 py-0.5 rounded-full bg-[#d926a9]/30 text-pink-300 text-[10px] font-bold border border-[#d926a9]/40 tracking-wider">
                      +18
                    </span>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-zinc-400">personaje:</span>
                    <span className="font-semibold text-white/90 capitalize">
                      {scenario.characterRole || persona.name}
                    </span>
                  </div>
                  {scenario.storyType && (
                    <span className="text-[10px] text-zinc-400 bg-white/5 border border-white/5 px-2 py-0.5 rounded-full">
                      {scenario.storyType}
                    </span>
                  )}
                </div>
              </div>

              {/* Quick action: If not in call, show call button right on the card */}
              <button
                onClick={onToggleCall}
                className="mt-4 w-full py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 backdrop-blur-md flex items-center justify-center gap-2 text-xs font-medium text-white transition-all cursor-pointer active:scale-98"
              >
                <Phone className="w-3.5 h-3.5 text-pink-400" />
                <span>Hablar por llamada de voz</span>
              </button>
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: INTERACTIVE ROLEPLAY CHAT & STORY NARRATIVE */}
        <div className={`
          ${activeTab === 'scene' ? 'hidden' : 'flex'} 
          flex-1 flex-col h-[calc(100vh-5rem)] max-h-[820px] 
          bg-[#130f1e]/90 border border-white/10 rounded-[28px] 
          overflow-hidden shadow-2xl relative
        `}>
          {/* Chat Header (Matches user image: "secreto de hermanastros" + "Reiniciar") */}
          <div className="p-4 sm:px-6 border-b border-white/5 flex items-center justify-between bg-[#171224] shrink-0">
            <div>
              <h3 className="text-base font-bold text-white capitalize tracking-tight">
                {scenario.title}
              </h3>
              <p className="text-[11px] text-zinc-400 hidden sm:block">
                Interacción narrativa en tiempo real
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onRestartStory}
                className="flex items-center gap-1.5 text-zinc-400 hover:text-white text-xs font-medium px-3 py-1.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                title="Reiniciar la historia y limpiar la memoria"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reiniciar</span>
              </button>

              <button
                onClick={onToggleAutoSpeak}
                className="text-zinc-400 hover:text-white p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                title="Alternar reproducción de voz"
              >
                {autoSpeak ? <Volume2 className="w-4 h-4 text-pink-400" /> : <VolumeX className="w-4 h-4 text-zinc-500" />}
              </button>
            </div>
          </div>

          {/* Messages & Narrative Stream */}
          <div 
            ref={chatScrollRef}
            className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 scroll-smooth"
          >
            {messages.map((m) => {
              const isUser = m.sender === 'user';

              return (
                <div 
                  key={m.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  {isUser ? (
                    /* User bubble: Vibrant magenta/fuchsia (Matches user screenshot) */
                    <div className="max-w-[88%] sm:max-w-[75%] bg-gradient-to-r from-[#c026d3] to-[#d92a8b] text-white p-4 rounded-2xl rounded-tr-sm shadow-md">
                      <p className="text-sm leading-relaxed whitespace-pre-wrap font-normal">
                        {m.text}
                      </p>
                      <div className="text-[10px] text-white/70 text-right mt-1.5 font-mono">
                        {formatTimestamp(m.timestamp)}
                      </div>
                    </div>
                  ) : (
                    /* AI / Character bubble: Dark slate/purple with italics for narrative + "Ilustrar esta escena" */
                    <div className="max-w-[92%] sm:max-w-[85%] bg-[#1a1528] border border-purple-500/20 text-zinc-200 p-4 sm:p-5 rounded-2xl rounded-tl-sm shadow-md">
                      {/* Formatted story text */}
                      <div className="text-sm sm:text-[14.5px] leading-relaxed whitespace-pre-wrap font-normal space-y-2">
                        {m.text.split('\n').map((paragraph, idx) => {
                          // Check if paragraph contains narrative action (*action*) or dialogue
                          return (
                            <p key={idx} className="leading-relaxed">
                              {paragraph}
                            </p>
                          );
                        })}
                      </div>

                      {/* Timestamp */}
                      <div className="text-[10px] text-zinc-500 mt-2 font-mono">
                        {formatTimestamp(m.timestamp)}
                      </div>

                      {/* Illustration display if already generated for this message */}
                      {(sceneImages[m.id] || m.sceneImage) && (
                        <div className="mt-3 relative rounded-xl overflow-hidden border border-purple-500/30 group bg-black/40 shadow-lg">
                          <img 
                            src={sceneImages[m.id] || m.sceneImage} 
                            alt="Ilustración de la escena" 
                            className="w-full aspect-video max-h-80 object-cover transition-transform duration-500 group-hover:scale-102"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              const img = e.currentTarget;
                              if (!img.src.includes('seed=88421')) {
                                img.src = `https://image.pollinations.ai/prompt/${encodeURIComponent('Cinematic 35mm photo romantic lovers passion kitchen 8k')}&width=1024&height=576&nologo=true&seed=88421`;
                              }
                            }}
                          />
                          {/* Character persistence badge */}
                          <div className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md border border-purple-500/30 text-[10px] text-pink-300 font-medium flex items-center gap-1.5 shadow pointer-events-none">
                            <Sparkles className="w-3 h-3 text-pink-400" />
                            <span>Persistencia de {scenario.characterName || persona.name}</span>
                          </div>

                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
                            <button
                              onClick={() => setPreviewImage(sceneImages[m.id] || m.sceneImage!)}
                              className="px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur-md text-white text-xs flex items-center gap-1.5 hover:bg-black/80 transition-all cursor-pointer"
                            >
                              <Maximize2 className="w-3.5 h-3.5" />
                              <span>Ver</span>
                            </button>
                            <button
                              onClick={() => onSetCardMedia(sceneImages[m.id] || m.sceneImage!)}
                              className="px-3 py-1.5 rounded-lg bg-pink-600/90 backdrop-blur-md text-white text-xs flex items-center gap-1.5 hover:bg-pink-500 transition-all cursor-pointer font-medium"
                              title="Poner en la tarjeta izquierda (opcional)"
                            >
                              <ImageIcon className="w-3.5 h-3.5" />
                              <span>Poner en la tarjeta</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Loading skeleton placeholder while generating image */}
                      {generatingMessageId === m.id && !(sceneImages[m.id] || m.sceneImage) && (
                        <div className="mt-3 rounded-xl overflow-hidden border border-pink-500/30 bg-pink-950/20 aspect-video flex flex-col items-center justify-center gap-2 animate-pulse p-4 text-center">
                          <Loader2 className="w-6 h-6 animate-spin text-pink-400" />
                          <p className="text-xs text-pink-300 font-medium">Ilustrando escena con IA...</p>
                          <p className="text-[11px] text-zinc-400">Capturando la acción física y ambiente del momento</p>
                        </div>
                      )}

                      {/* "✨ Ilustrar esta escena" action button (Matches user screenshot) */}
                      <div className="mt-2.5 pt-2 border-t border-white/5 flex items-center justify-between">
                        <button
                          onClick={() => handleIllustrateScene(m)}
                          disabled={generatingMessageId === m.id}
                          className="text-xs text-pink-400 hover:text-pink-300 font-medium flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                        >
                          {generatingMessageId === m.id ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin text-pink-400" />
                              <span className="italic">Ilustrando escena con IA...</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                              <span>{(sceneImages[m.id] || m.sceneImage) ? 'Re-ilustrar escena' : 'Ilustrar esta escena'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* AI Typing / Generating Indicator */}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-[#1a1528] border border-purple-500/20 text-zinc-400 px-4 py-3 rounded-2xl rounded-tl-sm flex items-center gap-2">
                  <span className="text-xs italic">El personaje está respondiendo...</span>
                  <div className="flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 bg-pink-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="w-1.5 h-1.5 bg-fuchsia-400 rounded-full animate-bounce" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Chat Input Bar (Matches user image) */}
          <div className="p-3 sm:p-4 border-t border-white/5 bg-[#171224] shrink-0">
            <div className="flex items-center gap-2 bg-[#1c172b] border border-white/10 rounded-2xl px-3 py-2 focus-within:border-purple-500 transition-colors">
              <input 
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Escribe tu mensaje..."
                className="flex-1 bg-transparent text-sm text-white placeholder-zinc-500 outline-none px-2 py-1"
              />

              {/* Voice dictation button */}
              <button
                onClick={handleToggleVoiceInput}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isListeningMic ? 'bg-red-600 text-white animate-pulse' : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
                title={isListeningMic ? "Detener dictado" : "Dictar mensaje por voz"}
              >
                <Mic className="w-4 h-4" />
              </button>

              {/* Send button (Vibrant purple/magenta) */}
              <button
                onClick={handleSend}
                disabled={!inputText.trim()}
                className="px-4 py-2 bg-gradient-to-r from-[#c026d3] to-[#d92a8b] hover:from-[#d92a8b] hover:to-[#e11d48] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Enviar</span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* FULL IMAGE PREVIEW MODAL */}
      {previewImage && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-4">
          <button
            onClick={() => setPreviewImage(null)}
            className="absolute top-6 right-6 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="max-w-2xl max-h-[80vh] rounded-2xl overflow-hidden border border-white/20 shadow-2xl">
            <img 
              src={previewImage} 
              alt="Escena ampliada" 
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={() => {
                onSetCardMedia(previewImage);
                setPreviewImage(null);
              }}
              className="px-5 py-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-sm font-semibold flex items-center gap-2 shadow-lg transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Usar como imagen de la tarjeta izquierda</span>
            </button>
          </div>
        </div>
      )}

      {/* SCENARIO EDIT MODAL (Full featured matching CreateStoryModal) */}
      <EditStoryModal
        isOpen={isEditingMetadata}
        onClose={() => setIsEditingMetadata(false)}
        scenario={scenario}
        onSave={(updated, restartChat) => {
          onUpdateScenario(updated, restartChat);
        }}
      />
    </div>
  );
};
export default StoryRoleplayView;
